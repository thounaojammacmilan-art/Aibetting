import React from 'react';
import { ChevronLeft, Zap, Trophy, Flame, Play, Sparkles, BookOpen } from 'lucide-react';
import { BettingSlipAnalysis } from '../types';

interface MatchDetailViewProps {
  analysis: BettingSlipAnalysis;
  onBack: () => void;
}

export default function MatchDetailView({ analysis, onBack }: MatchDetailViewProps) {
  const { teams, analytics, tournament, prediction } = analysis;

  // Let's create realistic comparative stat bars
  const stats = [
    { label: 'Attack Index', home: analytics.homeMomentum, away: analytics.awayMomentum },
    { label: 'Defense Stability', home: 100 - analytics.awayMomentum + 10, away: 100 - analytics.homeMomentum + 8 },
    { label: 'Possession Control', home: analytics.homeMomentum > 80 ? 58 : 52, away: analytics.homeMomentum > 80 ? 42 : 48 },
    { label: 'Set Piece Efficiency', home: 80, away: 72 },
    { label: 'Late Game Volatility', home: analytics.matchVolatility === 'HIGH' ? 88 : 45, away: analytics.matchVolatility === 'HIGH' ? 91 : 42 },
  ];

  return (
    <div className="space-y-6 pb-20">
      {/* Back button and Header */}
      <div className="flex items-center gap-2">
        <button
          onClick={onBack}
          className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-white active:scale-95 transition-transform"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <div>
          <h2 className="text-xs font-black text-white uppercase tracking-wider">TACTICAL PLAYBOOK</h2>
          <p className="text-[10px] text-gray-500 font-mono">FIXTURE ANALYTICAL CORRELATION</p>
        </div>
      </div>

      {/* Matchup Header */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-[#00FF41]/5 rounded-full blur-2xl -z-10" />
        <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">{tournament}</span>
        <div className="flex items-center justify-center gap-6 mt-2">
          <div className="flex-1 text-right">
            <h3 className="text-sm font-black text-white">{teams.home}</h3>
            {/* Form indicators */}
            <div className="flex justify-end gap-1 mt-1">
              {analytics.homeForm.map((f, i) => (
                <span
                  key={i}
                  className={`w-4 h-4 rounded text-[9px] font-black flex items-center justify-center ${
                    f === 'W' ? 'bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/20' : f === 'D' ? 'bg-white/5 text-gray-400' : 'bg-red-950/40 text-[#FF3B30] border border-red-900/10'
                  }`}
                >
                  {f}
                </span>
              ))}
            </div>
          </div>

          <div className="w-10 h-10 rounded-full bg-black/40 border border-white/10 flex items-center justify-center text-xs font-black text-[#00FF41] font-mono shadow-inner">
            VS
          </div>

          <div className="flex-1 text-left">
            <h3 className="text-sm font-black text-white">{teams.away}</h3>
            <div className="flex justify-start gap-1 mt-1">
              {analytics.awayForm.map((f, i) => (
                <span
                  key={i}
                  className={`w-4 h-4 rounded text-[9px] font-black flex items-center justify-center ${
                    f === 'W' ? 'bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/20' : f === 'D' ? 'bg-white/5 text-gray-400' : 'bg-red-950/40 text-[#FF3B30] border border-red-900/10'
                  }`}
                >
                  {f}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Momentum index sliders */}
        <div className="mt-4 pt-4 border-t border-white/5 grid grid-cols-2 gap-4">
          <div className="space-y-1 text-left">
            <span className="text-[9px] text-gray-400 font-mono uppercase">Attack Momentum</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-white font-mono">{analytics.homeMomentum}%</span>
              <div className="h-1 bg-white/5 rounded-full flex-1">
                <div className="h-full bg-gradient-to-r from-[#008F24] to-[#00FF41] rounded-full" style={{ width: `${analytics.homeMomentum}%` }} />
              </div>
            </div>
          </div>
          <div className="space-y-1 text-left">
            <span className="text-[9px] text-gray-400 font-mono uppercase">Defense Momentum</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-white font-mono">{analytics.awayMomentum}%</span>
              <div className="h-1 bg-white/5 rounded-full flex-1">
                <div className="h-full bg-gradient-to-r from-[#008F24] to-[#00FF41] rounded-full" style={{ width: `${analytics.awayMomentum}%` }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Head-to-Head Breakdown details */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2.5">
        <h4 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
          <Trophy className="w-4 h-4 text-[#D4AF37]" />
          Historical Head-To-Head Correlation
        </h4>
        <div className="p-3 bg-black/40 rounded-xl border border-white/5">
          <p className="text-xs text-gray-300 leading-relaxed font-sans">{analytics.headToHead}</p>
          <div className="flex items-center gap-1.5 mt-2.5 text-[10px] text-[#00FF41] font-mono uppercase leading-none">
            <Zap className="w-3.5 h-3.5 animate-pulse" /> Match Volatility: {analytics.matchVolatility} VOLUME
          </div>
        </div>
      </div>

      {/* Statistical Performance Comparative Bars */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-4">
        <h4 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
          <Flame className="w-3.5 h-3.5 text-[#00FF41]" />
          AI Tactical Index Comparison
        </h4>

        <div className="space-y-3.5">
          {stats.map((stat, i) => (
            <div key={i} className="space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-black font-mono text-gray-300">
                <span>{stat.home}%</span>
                <span className="text-[10px] text-gray-400 font-mono text-center font-normal">{stat.label}</span>
                <span>{stat.away}%</span>
              </div>
              <div className="h-2 bg-black rounded-full flex overflow-hidden border border-white/5">
                <div 
                  className="bg-gradient-to-r from-[#008F24] to-[#00FF41] h-full transition-all duration-500 ease-out flex justify-end rounded-l-full" 
                  style={{ width: `${(stat.home / (stat.home + stat.away)) * 100}%` }}
                />
                <div 
                  className="bg-[#00FF41] bg-opacity-10 h-full transition-all duration-500 ease-out rounded-r-full" 
                  style={{ width: `${(stat.away / (stat.home + stat.away)) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Playbook Tactical Insight Commentary */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2">
        <h4 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5 border-b border-white/5 pb-2">
          <BookOpen className="w-4 h-4 text-[#00FF41]" />
          Match Playbook Insight
        </h4>
        <p className="text-xs text-gray-350 leading-relaxed font-sans pt-1">
          {analytics.tacticalInsight}
        </p>
        <div className="flex items-center justify-between p-2.5 mt-2.5 bg-[#00FF41]/5 border border-[#00FF41]/20 rounded-xl">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#00FF41]" />
            <p className="text-[11px] text-gray-300 font-medium">Dominion Advantage Scale</p>
          </div>
          <span className="text-xs text-[#00FF41] font-mono font-black">{analytics.dominionLevel}%</span>
        </div>
      </div>

      {/* Safety Compliance Footnote */}
      <p className="text-[9px] text-gray-500 text-center leading-relaxed max-w-xs mx-auto">
        Forecast probability models are simulated mathematical equations using deep historical trend values and real physical parameters. No financial performance guarantees are stated or implied. Limit gambling activity responsibly.
      </p>
    </div>
  );
}
