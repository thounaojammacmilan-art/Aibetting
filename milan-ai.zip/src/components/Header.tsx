import React from 'react';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-white/10 px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-gradient-to-tr from-[#00FF41] to-[#008F24] rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(0,255,65,0.4)]">
          <span className="text-black font-black text-xs italic">ML</span>
        </div>
        <div>
          <h1 className="text-xs font-black tracking-tight text-white uppercase leading-none">
            MILAN <span className="text-[#00FF41]">AI</span>
          </h1>
          <p className="text-[8px] text-gray-500 font-mono tracking-wider mt-0.5">SPORTS ANALYTICS COGNITIVE</p>
        </div>
      </div>
    </header>
  );
}
