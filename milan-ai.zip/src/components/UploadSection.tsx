import React, { useState, useRef } from 'react';
import { Upload, Clipboard, CheckCircle2, RefreshCw, AlertCircle, Sparkles, BookOpen } from 'lucide-react';
import { PRESET_SLIPS } from '../data/presets';
import { BettingSlipAnalysis } from '../types';

interface UploadSectionProps {
  onAnalysisStarted: () => void;
  onAnalysisCompleted: (result: BettingSlipAnalysis) => void;
}

export default function UploadSection({ onAnalysisStarted, onAnalysisCompleted }: UploadSectionProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [scanningStatus, setScanningStatus] = useState<string | null>(null);
  const [scanningStep, setScanningStep] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const steps = [
    'Initializing neural screenshot matrix...',
    'Decrypting platform layout matches (1xBet/Stake)...',
    'Extracting tournament fixtures and odds fields...',
    'Synthesizing historical momentum arrays...',
    'Performing advanced Monte Carlo score risk hedge maps...',
    'Rendering sports analytic prediction dashboard...'
  ];

  const handlePresetSelect = (preset: BettingSlipAnalysis) => {
    runScanningSequence(preset);
  };

  const runScanningSequence = (resultData: BettingSlipAnalysis) => {
    onAnalysisStarted();
    setScanningStatus(steps[0]);
    setScanningStep(0);
    setErrorMessage(null);

    let progress = 0;
    const interval = setInterval(() => {
      progress += 1;
      if (progress < steps.length) {
        setScanningStep(progress);
        setScanningStatus(steps[progress]);
      } else {
        clearInterval(interval);
        setScanningStatus(null);
        onAnalysisCompleted(resultData);
      }
    }, 1000);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMessage('Unsupported format. Please upload a PNG, JPG, or high-res betting screenshot.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      const base64String = reader.result as string;
      // Start processing base64 image via real backend
      onAnalysisStarted();
      setScanningStatus(steps[0]);
      setScanningStep(0);
      setErrorMessage(null);

      // We simulate scanning steps while concurrently fetching the actual backend parsing
      let currentProgress = 0;
      const stepTimer = setInterval(() => {
        if (currentProgress < steps.length - 2) {
          currentProgress += 1;
          setScanningStep(currentProgress);
          setScanningStatus(steps[currentProgress]);
        }
      }, 700);

      try {
        const response = await fetch('/api/analyze-screenshot', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64String })
        });

        const data = await response.json();
        clearInterval(stepTimer);

        if (response.ok && data.isSlipValidOrDetected) {
          setScanningStep(steps.length - 1);
          setScanningStatus(steps[steps.length - 1]);
          setTimeout(() => {
            setScanningStatus(null);
            onAnalysisCompleted(data);
          }, 800);
        } else {
          // If slip parser could not extract clean teams, getSimulatedAnalysisFromRandomUpload outputs a generic one, which we use
          setScanningStep(steps.length - 1);
          setScanningStatus('Refining raw predictions...');
          setTimeout(() => {
            setScanningStatus(null);
            onAnalysisCompleted(data);
          }, 800);
        }
      } catch (err) {
        clearInterval(stepTimer);
        console.error('Offline / Network error analyzing screenshot:', err);
        setErrorMessage('Connection failed. Using premium local analytics fallback.');
        // Graceful fallback instantly to the first preset slip so they can test
        setTimeout(() => {
          setScanningStatus(null);
          onAnalysisCompleted(PRESET_SLIPS[0]);
        }, 1200);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      {/* Visual scanning overlay */}
      {scanningStatus && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center px-6">
          <div className="w-full max-w-xs text-center space-y-6">
            {/* Pulsing Scan Animation */}
            <div className="relative w-28 h-28 mx-auto bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center overflow-hidden">
              <Sparkles className="w-10 h-10 text-[#00FF41] animate-pulse" />
              {/* Green holographic scanning line */}
              <div className="absolute left-0 right-0 h-0.5 bg-[#00FF41] opacity-75 shadow-[0_0_15px_#00FF41] animate-bounce w-full top-0" style={{ animationDuration: '2s' }} />
            </div>

            <div className="space-y-2">
              <h3 className="text-xs font-black tracking-wider text-[#00FF41] font-mono uppercase">
                AI SCANNING IN PROGRESS
              </h3>
              <p className="text-xs text-gray-400 font-mono min-h-[40px] leading-relaxed">
                {scanningStatus}
              </p>
            </div>

            {/* Stepper Dots */}
            <div className="flex justify-center gap-1.5 py-1">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-1.5 rounded-full transition-all duration-300 ${
                    index === scanningStep ? 'w-5 bg-[#00FF41]' : index < scanningStep ? 'w-2 bg-[#00FF41]/40' : 'w-1.5 bg-neutral-800'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Hero Intro */}
      <div className="relative bg-white/5 border border-white/10 rounded-2xl p-5 text-center overflow-hidden">
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-[#00FF41]/10 rounded-full blur-2xl -z-10" />
        <h2 className="text-base font-black text-white tracking-tight">AI Screenshot Analyzer</h2>
        <p className="text-xs text-gray-400 mt-1 max-w-sm mx-auto leading-relaxed">
          Upload any betting slip screenshot from <span className="text-[#00FF41] font-bold">1xBet</span>,{' '}
          <span className="text-[#00FF41] font-bold">Stake</span>, or <span className="text-[#00FF41] font-bold">Bet365</span>. 
          The neural core decodes matchups, tests momentum, and generates safe hedging suggestions!
        </p>
      </div>

      {/* Main Drag-and-Drop Area */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleFileDrop}
        onClick={triggerFileSelect}
        className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-305 min-h-[220px] ${
          isDragging
            ? 'border-[#00FF41] bg-[#00FF41]/5 shadow-[0_0_20px_rgba(0,255,65,0.1)]'
            : 'border-white/10 hover:border-white/20 bg-white/[0.02]'
        }`}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept="image/*"
          className="hidden"
        />

        <div className="w-12 h-12 rounded-full bg-black/40 border border-white/10 flex items-center justify-center mb-3 shadow-inner">
          <Upload className={`w-5 h-5 ${isDragging ? 'text-[#00FF41] animate-bounce' : 'text-gray-400'}`} />
        </div>

        <p className="text-xs font-black text-white uppercase tracking-tight">
          Drag & Drop or Tap to Browse
        </p>
        <p className="text-[10px] text-gray-500 mt-1">
          Supports PNG, JPEG bet slips
        </p>

        <div className="mt-4 flex items-center gap-1.5 bg-black/40 border border-white/10 rounded-full px-3 py-1 text-[10px] text-[#00FF41] font-mono">
          <Clipboard className="w-3 h-3" />
          Supports direct mobile screenshot uploads
        </div>
      </div>

      {errorMessage && (
        <div className="bg-red-950/20 border border-red-900/40 rounded-xl p-3 flex items-start gap-2 text-red-400 text-[11px] leading-snug">
          <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <div>{errorMessage}</div>
        </div>
      )}

      {/* Interactive Presets Section */}
      <div className="space-y-3">
        <div className="flex items-center gap-1.5">
          <BookOpen className="w-4 h-4 text-[#00FF41]" />
          <h3 className="text-xs font-black uppercase tracking-wider text-gray-300">
            Interactive Test Slips (No file required)
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {PRESET_SLIPS.map((slip) => (
            <button
              key={slip.id}
              onClick={() => handlePresetSelect(slip)}
              className="group text-left bg-white/5 border border-white/10 rounded-xl p-3 hover:border-white/20 active:scale-[0.99] transition-all flex items-start justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-black tracking-wider uppercase font-mono px-1.5 py-0.5 rounded bg-black border border-white/10 text-gray-300">
                    {slip.platformLogo}
                  </span>
                  <span className="text-xs font-black text-white group-hover:text-[#00FF41] transition-colors leading-none">
                    {slip.label}
                  </span>
                </div>
                <p className="text-[10px] text-gray-400 leading-relaxed">
                  {slip.description}
                </p>
              </div>

              <div className="flex items-center gap-1 text-[10px] font-black bg-[#00FF41] text-black px-2.5 py-1 rounded">
                ODDS {slip.oddsOnSlip}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
