import React, { useState, useEffect } from 'react';
import { TrendingUp, Flame, BadgePercent, ChevronRight, Loader2, Sparkles } from 'lucide-react';
import { MOCK_TRENDING } from '../data/presets';
import { TrendingPick, BettingSlipAnalysis } from '../types';

interface TrendingPicksProps {
  onSelectPreset: (preset: BettingSlipAnalysis) => void;
}

export default function TrendingPicks({ onSelectPreset }: TrendingPicksProps) {
  const [picks, setPicks] = useState<TrendingPick[]>(MOCK_TRENDING);
  const [loadingPicks, setLoadingPicks] = useState(false);
  const [analyzingItem, setAnalyzingItem] = useState<string | null>(null);

  // Fetch live trending picks from API on mount
  useEffect(() => {
    let active = true;
    const fetchPicks = async () => {
      setLoadingPicks(true);
      try {
        const response = await fetch('/api/trending-picks');
        if (response.ok) {
          const data = await response.json();
          if (active && data.picks && Array.isArray(data.picks)) {
            setPicks(data.picks);
          }
        }
      } catch (err) {
        console.error('Failed to fetch real-time trending picks:', err);
      } finally {
        if (active) setLoadingPicks(false);
      }
    };

    fetchPicks();
    return () => {
      active = false;
    };
  }, []);

  const handleItemClicks = async (pick: TrendingPick) => {
    setAnalyzingItem(`${pick.homeTeam} vs ${pick.awayTeam}`);
    try {
      const response = await fetch('/api/analyze-fixture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          homeTeam: pick.homeTeam,
          awayTeam: pick.awayTeam,
          tournament: pick.tournament
        })
      });

      if (response.ok) {
        const analysisData = await response.json();
        onSelectPreset(analysisData);
      } else {
        throw new Error('Analysis response was not OK');
      }
    } catch (err) {
      console.error('Error performing dynamic trend analysis:', err);
      // Direct failover to highly-styled toast
    } finally {
      setAnalyzingItem(null);
    }
  };

  return (
    <div className="space-y-6 pb-20 relative">
      {/* Visual scanning overlay when analyzing a clicked trend */}
      {analyzingItem && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center px-6">
          <div className="w-full max-w-xs text-center space-y-6">
            <div className="relative w-28 h-28 mx-auto bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center overflow-hidden">
              <Sparkles className="w-10 h-10 text-[#00FF41] animate-pulse" />
              <div className="absolute left-0 right-0 h-0.5 bg-[#00FF41] opacity-75 shadow-[0_0_15px_#00FF41] animate-bounce w-full top-0" style={{ animationDuration: '2s' }} />
            </div>

            <div className="space-y-2">
              <h3 className="text-xs font-black tracking-wider text-[#00FF41] font-mono uppercase">
                AI COGNITIVE MULTI-MODEL SCAN
              </h3>
              <p className="text-xs text-neutral-300 font-mono min-h-[40px] leading-relaxed">
                Analyzing form systems & volatility matrices for <span className="text-white font-bold">{analyzingItem}</span>...
              </p>
            </div>
            <div className="flex justify-center items-center gap-1.5 py-1 text-xs text-neutral-500 font-mono">
              <Loader2 className="w-4 h-4 animate-spin text-[#00FF41]" /> Using live sports feed
            </div>
          </div>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-neutral-200 uppercase flex items-center gap-1.5">
            <TrendingUp className="text-[#00E676] w-4.5 h-4.5" />
            Market Core Trends
          </h2>
          <p className="text-[10px] text-neutral-500 font-mono">REAL-TIME SPORTSBOOK HIGHLIGHTS</p>
        </div>

        {loadingPicks && (
          <div className="flex items-center gap-1 text-[10px] text-[#00E676] font-mono">
            <Loader2 className="w-3 h-3 animate-spin" />
            Updating Feed...
          </div>
        )}
      </div>

      {/* Dynamic Heat Notice */}
      <div className="bg-gradient-to-r from-red-950/20 to-neutral-900 border border-neutral-800/80 rounded-2xl p-4 space-y-1 relative overflow-hidden">
        <div className="absolute right-3 top-3 text-red-500 animate-pulse">
          <Flame className="w-5 h-5" />
        </div>
        <p className="text-xs font-bold text-neutral-200 uppercase flex items-center gap-1">
          Market Volume Tracker
        </p>
        <p className="text-[11px] text-neutral-400 leading-normal max-w-[85%] font-sans">
          EPL Combo parameters and NBA Playoff handicap arrays are hitting historical analysis heights this hour. Tap any trend below to launch live predictive intelligence models.
        </p>
      </div>

      {/* Main Trends list */}
      <div className="space-y-3">
        {picks.map((pick: TrendingPick) => (
          <div
            key={pick.id}
            onClick={() => handleItemClicks(pick)}
            className="group bg-neutral-900 border border-neutral-800/80 hover:border-neutral-700/80 rounded-2xl p-4 transition-all duration-200 cursor-pointer flex items-center justify-between gap-4 active:scale-[0.99]"
          >
            <div className="space-y-2 flex-1 min-w-0">
              <div className="flex items-center gap-1.5 text-[10px] font-mono whitespace-nowrap text-neutral-500">
                <span>{pick.tournament}</span>
                <span>•</span>
                <span className="text-[#00E676] bg-[#00E676]/5 border border-[#00E676]/10 px-1.5 py-0.2 rounded font-bold uppercase">
                  {pick.analyzedCount} scans
                </span>
              </div>

              <div>
                <h3 className="text-xs font-black text-neutral-200 group-hover:text-[#00FF41] transition-colors leading-tight">
                  {pick.homeTeam} <span className="text-neutral-500 font-normal">vs</span> {pick.awayTeam}
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] text-neutral-400 font-mono">Market: {pick.betType}</span>
                  <span className="text-[10px] text-neutral-300 font-mono font-bold bg-neutral-950 border border-neutral-850 px-1.5 py-0.2 rounded">
                    Odds {pick.odds}
                  </span>
                </div>
              </div>

              {/* Form Bar indicator */}
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[9px] text-neutral-500 uppercase font-mono tracking-wider">Home / Away Form:</span>
                <div className="flex gap-0.5">
                  {pick.formHome.map((f, idx) => (
                    <span
                      key={idx}
                      className={`w-3.5 h-3.5 text-[8px] font-black rounded flex items-center justify-center ${
                        f === 'W' ? 'bg-emerald-950/60 text-[#00E676]' : f === 'D' ? 'bg-neutral-800 text-neutral-400' : 'bg-red-950 text-red-400'
                      }`}
                    >
                      {f}
                    </span>
                  ))}
                </div>
                <span className="text-[9px] text-neutral-600">vs</span>
                <div className="flex gap-0.5">
                  {pick.formAway.map((f, idx) => (
                    <span
                      key={idx}
                      className={`w-3.5 h-3.5 text-[8px] font-black rounded flex items-center justify-center ${
                        f === 'W' ? 'bg-emerald-950/60 text-[#00E676]' : f === 'D' ? 'bg-[#2a2a2c] text-neutral-400' : 'bg-red-950 text-red-400'
                      }`}
                    >
                      {f}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Confidence indicator badge percent */}
            <div className="text-right shrink-0 flex flex-col items-end gap-1">
              <div className="w-10 h-10 rounded-full bg-neutral-950 border border-neutral-800 flex flex-col items-center justify-center group-hover:border-[#00FF41]/40 transition-all">
                <span className="text-xs font-black font-mono text-[#00FF41]">{pick.aiConfidence}%</span>
              </div>
              <span className="text-[9px] text-neutral-400 font-mono text-center block w-10">AI CONF</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
