import React from 'react';
import { 
  CheckCircle2, 
  HelpCircle, 
  TrendingUp, 
  ShieldAlert, 
  Gauge, 
  ArrowRight, 
  Sparkles, 
  Coins,
  ChevronRight,
  TrendingDown,
  Percent
} from 'lucide-react';
import { BettingSlipAnalysis } from '../types';

interface AnalysisDashboardProps {
  analysis: BettingSlipAnalysis;
  onViewMatchDetails: () => void;
  onOptimizeParlay: (updatedAnalysis: BettingSlipAnalysis) => void;
  onNewScan?: () => void;
}

export default function AnalysisDashboard({ analysis, onViewMatchDetails, onOptimizeParlay, onNewScan }: AnalysisDashboardProps) {
  const { prediction, analytics, parlayAnalyzer, teams, tournament, betType, oddsOnSlip, detectedPlatform } = analysis;

  // Choose colors based on risk level
  const getRiskBadgeStyles = (risk: 'LOW' | 'MEDIUM' | 'HIGH') => {
    switch (risk) {
      case 'LOW':
        return 'bg-[#00FF41]/10 border border-[#00FF41]/30 text-[#00FF41]';
      case 'MEDIUM':
        return 'bg-amber-950/40 border border-amber-900/40 text-amber-400';
      case 'HIGH':
        return 'bg-red-950/40 border border-red-900/40 text-[#FF3B30] shadow-[0_0_15px_rgba(255,59,48,0.2)]';
    }
  };

  const hasParlay = !!parlayAnalyzer && parlayAnalyzer.individualMatches && parlayAnalyzer.individualMatches.length > 0;

  const runParlayOptimization = () => {
    if (!parlayAnalyzer) return;
    
    // Simulate smart replacement optimization
    const updated: BettingSlipAnalysis = {
      ...analysis,
      oddsOnSlip: parlayAnalyzer.optimizedCombinedOdds,
      betType: 'AI Optimized Parlay (Safety Balanced)',
      parlayAnalyzer: {
        ...parlayAnalyzer,
        overallSlipRisk: 'LOW',
        summary: '🎉 Hedges successfully applied! Unstable legs have been minimized.'
      }
    };
    onOptimizeParlay(updated);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Platform & Metadata Ribbons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1">
          <span className="text-[9px] font-mono font-black tracking-wider rounded uppercase px-1.5 bg-black text-gray-300">
            {detectedPlatform}
          </span>
          <span className="text-[10px] text-gray-400 font-mono">Verified Slip</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-gray-500 font-mono">
            {new Date(analysis.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
          {onNewScan && (
            <button
              onClick={onNewScan}
              className="text-[10px] font-black text-[#00FF41] hover:bg-[#00FF41]/10 bg-transparent px-2.5 py-1 rounded-full border border-[#00FF41]/30 flex items-center gap-1 transition-all active:scale-95"
            >
              Scan New
            </button>
          )}
        </div>
      </div>

      {/* Hero Overview Card (Probability dial / Predicted score) */}
      <div className="bg-white/5 border border-white/10 rounded-2xl p-5 relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 w-36 h-36 bg-[#00FF41]/5 rounded-full blur-3xl -z-10" />

        <div className="text-center space-y-1">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{tournament}</p>
          <h2 className="text-lg font-black text-white tracking-tight leading-tight">
            {teams.home} <span className="text-gray-505 font-normal">vs</span> {teams.away}
          </h2>
          <div className="flex items-center justify-center gap-2 mt-1.5">
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-black/40 text-gray-400 border border-white/5 font-mono">
              Slip Bet: {betType}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-[#D4AF37]/10 border border-[#D4AF37]/35 text-[#D4AF37] font-mono font-black">
              Odds {oddsOnSlip}
            </span>
          </div>
        </div>

        {/* Dynamic Circular Dial & Prediction Metas */}
        <div className="grid grid-cols-2 gap-4 items-center pt-5 border-t border-white/5 mt-4">
          <div className="flex flex-col items-center justify-center relative">
            {/* Probability Circle SVG */}
            <div className="relative w-28 h-28 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-95" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-white/5 fill-none"
                  strokeWidth="8"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  className="stroke-[#00FF41] fill-none animate-pulse"
                  strokeWidth="8"
                  strokeDasharray="264"
                  strokeDashoffset={264 - (264 * prediction.probabilityPercent) / 100}
                  strokeLinecap="round"
                />
              </svg>
              {/* Inner ring elements */}
              <div className="absolute text-center">
                <p className="text-2xl font-black text-white font-mono leading-none tracking-tighter">
                  {prediction.probabilityPercent}%
                </p>
                <p className="text-[9px] font-black text-gray-400 uppercase tracking-wider mt-0.5">
                  AI WIN INDEX
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div>
              <p className="text-[10px] font-black text-gray-400 tracking-wider uppercase font-mono">Predicted Score</p>
              <p className="text-lg font-black text-[#00FF41] tracking-tight font-mono">{prediction.predictedScore}</p>
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 tracking-wider uppercase font-mono">Risk Level</p>
              <span className={`inline-block text-[10px] px-2.5 py-0.5 rounded-full font-black mt-0.5 uppercase tracking-wide ${getRiskBadgeStyles(prediction.riskLevel)}`}>
                {prediction.riskLevel} RISK
              </span>
            </div>
            <div>
              <p className="text-[10px] font-black text-gray-400 tracking-wider uppercase font-mono">Confidence Level</p>
              <div className="flex items-center gap-2 mt-1">
                <div className="h-1.5 w-24 bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <div className="h-full bg-gradient-to-r from-[#008F24] to-[#00FF41] rounded-full" style={{ width: `${prediction.confidenceMeter}%` }} />
                </div>
                <span className="text-[9px] font-black text-gray-300 font-mono">{prediction.confidenceMeter}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Key Reasonings Section */}
      <div className="bg-white/5 border border-white/10 rounded-xl p-4 space-y-3">
        <h3 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5 border-b border-white/5 pb-2">
          <Sparkles className="w-3.5 h-3.5 text-[#00FF41]" />
          Neural Core Reasoning
        </h3>
        <ul className="space-y-2.5">
          {prediction.reasoning.map((point, i) => (
            <li key={i} className="flex items-start gap-2 text-xs text-gray-300 leading-normal">
              <span className="w-4 h-4 rounded-full bg-[#00FF41]/10 text-[#00FF41] flex items-center justify-center text-[10px] font-bold font-mono shrink-0 mt-0.5 border border-[#00FF41]/20">
                {i + 1}
              </span>
              <p>{point}</p>
            </li>
          ))}
        </ul>
      </div>

      {/* Alternative Pick (Hedge option) */}
      <div className="bg-[#00FF41]/15 border border-[#00FF41]/30 rounded-2xl p-4 space-y-2 relative overflow-hidden">
        <div className="absolute -right-4 -top-4 w-16 h-16 bg-[#00FF41]/15 rounded-full blur-xl" />
        <div className="absolute top-0 right-0 bg-[#D4AF37] text-black text-[9px] font-black px-2.5 py-0.5 rounded-bl">
          AI SAFER PICK
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse" />
          <h4 className="text-xs font-black text-white uppercase tracking-wider">Recommended Hedge Alternative</h4>
        </div>
        <div className="flex items-center justify-between bg-black/40 border border-white/5 p-2.5 rounded-xl">
          <div>
            <p className="text-[10px] text-gray-400 font-mono uppercase">Optimized Market Leg</p>
            <p className="text-xs font-bold text-white mt-0.5">{prediction.alternativeSaferPick.betType}</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-gray-400 font-mono uppercase">Hedge Odds</p>
            <p className="text-sm font-black text-[#00FF41] font-mono mt-0.5">{prediction.alternativeSaferPick.odds}</p>
          </div>
        </div>
        <p className="text-[10px] text-gray-300 leading-relaxed font-sans mt-2">
          Gemini Analysis: {prediction.alternativeSaferPick.reasoning} Simulated coverage with a win likelihood of <span className="text-[#00FF41] font-black font-mono">{prediction.alternativeSaferPick.probabilityPercent}%</span>.
        </p>
      </div>

      {/* Parlay Analyzer - Shows if multiple slips found */}
      {parlayAnalyzer && (
        <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-3 bg-[#D4AF37] rounded-full" />
              <h3 className="text-xs font-black uppercase tracking-wider text-white">
                Multi-Slip Parlay Optimizer
              </h3>
            </div>
            <span className={`text-[9px] font-black px-2.5 py-0.5 rounded-full tracking-wider uppercase ${getRiskBadgeStyles(parlayAnalyzer.overallSlipRisk)}`}>
              {parlayAnalyzer.overallSlipRisk} SLIP RISK
            </span>
          </div>

          <div className="bg-[#FF3B30]/10 border border-[#FF3B30]/30 rounded-xl p-3 space-y-1">
            <p className="text-[9px] font-black text-[#FF3B30] uppercase tracking-widest flex items-center gap-1 leading-none shadow-[0_0_10px_rgba(255,59,48,0.15)]">
              <ShieldAlert className="w-3.5 h-3.5" /> Weakest Comb Leg Detected
            </p>
            <p className="text-xs font-bold text-white pt-1">{parlayAnalyzer.weakestLink}</p>
            <p className="text-[11px] text-gray-400 leading-normal mt-0.5">
              This leg introduces volatility. Replacement suggestion: <span className="text-[#00FF41] font-bold">{parlayAnalyzer.suggestedReplacement}</span>
            </p>
          </div>

          {/* Sub-legs detailed list (simulated) */}
          {hasParlay && (
            <div className="space-y-2">
              <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Combo Leg Breakdown</p>
              <div className="space-y-1.5">
                {parlayAnalyzer.individualMatches!.map((m, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 bg-black/40 rounded-xl border border-white/5">
                    <div>
                      <p className="text-xs font-bold text-gray-200">{m.matchName}</p>
                      <p className="text-[10px] text-gray-400">{m.prediction} (Odds {m.detectedOdds})</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-block text-[9px] font-black px-1.5 py-0.2 rounded ${m.riskLevel === 'HIGH' ? 'bg-[#FF3B30]/10 border border-[#FF3B30]/20 text-[#FF3B30]' : 'bg-[#00FF41]/10 border border-[#00FF41]/20 text-[#00FF41]'}`}>
                        {m.probabilityPercent}% WIN
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Combined Odds Comparisons */}
          <div className="grid grid-cols-2 gap-3.5 pt-1 border-t border-white/5">
            <div className="p-2.5 bg-black/40 rounded-xl border border-white/5">
              <span className="text-[9px] text-gray-500 font-mono uppercase">Original Odds</span>
              <p className="text-base font-black text-gray-400 font-mono mt-0.5">{parlayAnalyzer.originalCombinedOdds}</p>
            </div>
            <div className="p-2.5 bg-[#00FF41]/10 border border-[#00FF41]/20 rounded-xl">
              <span className="text-[9px] text-[#00FF41] font-mono uppercase">Hedged Odds</span>
              <p className="text-base font-black text-[#00FF41] font-mono mt-0.5">{parlayAnalyzer.optimizedCombinedOdds}</p>
            </div>
          </div>

          <button
            onClick={runParlayOptimization}
            className="w-full bg-[#00FF41] text-black hover:scale-[0.98] font-black text-xs py-3.5 px-4 rounded-xl shadow-[0_8px_30px_rgba(0,255,65,0.2)] transition-all flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 stroke-[2.5]" />
            OPTIMIZE BET SLIP & APPLY SAFE HEDGES
          </button>
        </div>
      )}

      {/* CTAs */}
      <div className="space-y-2.5 pb-4">
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={onViewMatchDetails}
            className="bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold text-xs py-3 px-4 rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <TrendingUp className="w-4 h-4 text-[#00FF41]" />
            Detailed Playbook
          </button>

          <button
            onClick={() => {
              alert("Prediction shared successfully! Dynamic card saved to clipboard.");
            }}
            className="bg-[#00FF41]/10 hover:bg-[#00FF41]/15 border border-[#00FF41]/20 text-[#00FF41] font-bold text-xs py-3 px-4 rounded-xl transition flex items-center justify-center gap-1.5"
          >
            <Percent className="w-4 h-4" />
            Share Analysis
          </button>
        </div>

        {onNewScan && (
          <button
            onClick={onNewScan}
            className="w-full bg-[#00FF41]/10 hover:bg-[#00FF41]/20 border border-[#00FF41]/30 text-[#00FF41] font-black text-xs py-3.5 px-4 rounded-xl transition-all duration-200 flex items-center justify-center gap-2 active:scale-[0.98]"
          >
            SCAN ANOTHER BETTING SLIP
          </button>
        )}
      </div>
    </div>
  );
}
