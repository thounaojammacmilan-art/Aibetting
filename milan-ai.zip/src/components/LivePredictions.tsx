import React, { useState, useEffect } from 'react';
import { Play, RefreshCw, Compass, BadgePercent, Timer, Loader2 } from 'lucide-react';
import { MOCK_LIVE } from '../data/presets';
import { LiveMatch } from '../types';

export default function LivePredictions() {
  const [liveMatches, setLiveMatches] = useState<LiveMatch[]>(MOCK_LIVE);
  const [isSimulating, setIsSimulating] = useState(false);

  // Fetch live predictions from first-class backend
  const fetchLiveMatches = async (silent = false) => {
    if (!silent) setIsSimulating(true);
    try {
      const response = await fetch('/api/live-predictions');
      if (response.ok) {
        const data = await response.json();
        if (data.matches && Array.isArray(data.matches)) {
          setLiveMatches(data.matches);
        }
      }
    } catch (err) {
      console.error('Failed to retrieve live sports feeds:', err);
    } finally {
      setIsSimulating(false);
    }
  };

  useEffect(() => {
    fetchLiveMatches(true);

    // Auto-increment live match time
    const timeInterval = setInterval(() => {
      setLiveMatches((prevMatches) =>
        prevMatches.map((m) => {
          if (m.sport === 'Soccer') {
            return {
              ...m,
              minute: m.minute >= 90 ? 90 : m.minute + 1
            };
          } else {
            return m; 
          }
        })
      );
    }, 15000);

    return () => clearInterval(timeInterval);
  }, []);

  const triggerOddsShiftSimulation = () => {
    // We execute both a real-time fetch to pull any fresh matches and a visual odds-calculation shift
    setIsSimulating(true);
    setTimeout(() => {
      fetchLiveMatches(false);
    }, 800);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header section with simulation trigger */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-bold text-neutral-200 uppercase flex items-center gap-1.5 align-middle">
            <Compass className="text-[#00E676] w-4 h-4" />
            Live Market Feed
          </h2>
          <p className="text-[10px] text-neutral-500 font-mono">REAL-TIME RISK SHIFT MONITOR</p>
        </div>

        <button
          onClick={triggerOddsShiftSimulation}
          disabled={isSimulating}
          className="flex items-center gap-1.5 bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 px-3 py-1.5 rounded-full text-[10px] font-bold text-[#00E676] disabled:opacity-55 active:scale-95 transition-all cursor-pointer"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
          Force Market Refresh
        </button>
      </div>

      {/* Info Notice about market volatility */}
      <div className="bg-gradient-to-r from-neutral-900 to-indigo-950/20 border border-neutral-800/80 rounded-2xl p-3 flex items-start gap-4">
        <div className="w-8 h-8 rounded-lg bg-[#00E676]/10 border border-[#00E676]/30 flex items-center justify-center text-[#00E676] shrink-0 mt-0.5">
          <BadgePercent className="w-4 h-4 animate-pulse" />
        </div>
        <p className="text-[11px] text-neutral-400 leading-normal">
          <span className="text-[#00E676] font-semibold">Live Arbitrage Tracking:</span> Our intelligence engine watches global scoreboard movements and identifies odds overlays. Blinking <span className="text-emerald-400 font-bold">Green</span> signals high value, while <span className="text-red-400 font-bold">Red</span> signals safe-out hedging trigger.
        </p>
      </div>

      {isSimulating && liveMatches.length === 0 && (
        <div className="flex flex-col items-center justify-center p-12 text-neutral-500 gap-2">
          <Loader2 className="w-6 h-6 animate-spin text-[#00E676]" />
          <span className="text-xs font-mono">Connecting to global sportsbooks...</span>
        </div>
      )}

      {/* Live Match Cards */}
      <div className="space-y-4">
        {liveMatches.map((match) => (
          <div
            key={match.id}
            className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 space-y-4 relative overflow-hidden"
          >
            {/* Volatility Indicator strip */}
            <div className={`absolute top-0 left-0 right-0 h-1 ${match.volatility?.toUpperCase() === 'HIGH' ? 'bg-amber-500' : 'bg-[#00E676]'}`} />

            {/* League and Timer */}
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-neutral-500 uppercase font-semibold">{match.tournament}</span>
              <div className="flex items-center gap-1.5 text-red-500 font-black tracking-wider bg-red-950/50 border border-red-900/30 px-2 py-0.5 rounded-full animate-pulse">
                <Timer className="w-3.5 h-3.5 shrink-0" />
                {match.minute}'
              </div>
            </div>

            {/* Teams & Scoreboard */}
            <div className="flex items-center justify-between py-2 border-b border-neutral-850">
              <div className="flex-1 text-right">
                <h3 className="text-xs font-black text-neutral-200">{match.homeTeam}</h3>
                <span className="text-[10px] text-neutral-500 font-mono">Home Side</span>
              </div>

              {/* Dynamic Live Score */}
              <div className="px-5 text-center">
                <p className="text-lg font-black text-[#00E676] tracking-widest font-mono bg-neutral-950 border border-neutral-800 px-3 py-1 rounded-xl shadow-inner min-w-[70px]">
                  {match.score}
                </p>
                <span className="text-[8px] text-[#00E676] font-bold font-mono tracking-wider uppercase mt-1 inline-block animate-pulse">LIVE SCORING</span>
              </div>

              <div className="flex-1 text-left">
                <h3 className="text-xs font-black text-neutral-200">{match.awayTeam}</h3>
                <span className="text-[10px] text-neutral-500 font-mono">Away Side</span>
              </div>
            </div>

            {/* Live Odds Grid */}
            <div className="space-y-2">
              <p className="text-[9px] font-bold text-neutral-400 font-mono uppercase tracking-widest">Active Live Odds</p>
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-850 text-center">
                  <span className="text-[9px] text-neutral-500 font-mono block">WIN (1)</span>
                  <span className={`text-sm font-black font-mono transition-all duration-300 ${
                    match.oddsDirection === 'up' ? 'text-emerald-400' : 'text-red-400'
                  }`}>
                    {match.oddsHome ? match.oddsHome.toFixed(2) : '1.80'}
                  </span>
                </div>

                {match.oddsDraw > 0 ? (
                  <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-850 text-center">
                    <span className="text-[9px] text-neutral-500 font-mono block">DRAW (X)</span>
                    <span className="text-sm font-black text-neutral-300 font-mono">
                      {match.oddsDraw.toFixed(2)}
                    </span>
                  </div>
                ) : (
                  <div className="bg-neutral-950/40 p-2.5 rounded-xl border border-neutral-850/60 text-center flex items-center justify-center">
                    <span className="text-[9px] text-neutral-650 font-mono">N/A</span>
                  </div>
                )}

                <div className="bg-neutral-950 p-2.5 rounded-xl border border-neutral-850 text-center">
                  <span className="text-[9px] text-neutral-500 font-mono block">WIN (2)</span>
                  <span className={`text-sm font-black font-mono transition-all duration-300 ${
                    match.oddsDirection === 'down' ? 'text-emerald-400' : 'text-red-400'
                  }`}>
                    {match.oddsAway ? match.oddsAway.toFixed(2) : '2.10'}
                  </span>
                </div>
              </div>
            </div>

            {/* AI Real-time recommendation overlay */}
            <div className="bg-[#00E676]/5 border border-[#00E676]/25 rounded-xl p-3 flex justify-between items-center">
              <div>
                <span className="text-[9px] font-bold text-[#00E676] font-mono uppercase">AI Live Prediction Directive</span>
                <p className="text-xs font-bold text-neutral-200 mt-0.5">{match.aiPick}</p>
              </div>
              <div className="text-right">
                <span className="text-[9px] text-neutral-400 font-mono block animate-pulse">Confidence</span>
                <span className="text-xs font-black text-[#00E676] font-mono leading-none">{match.aiConfidence}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
