import React from 'react';
import { Home, Compass, Camera, MessageSquare, TrendingUp } from 'lucide-react';
import { motion } from 'motion/react';

interface BottomNavBarProps {
  currentTab: string;
  setTab: (tab: string) => void;
}

export default function BottomNavBar({ currentTab, setTab }: BottomNavBarProps) {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'live', label: 'Live Predictions', icon: Compass },
    { id: 'upload', label: 'AI Scan', icon: Camera, isCenter: true },
    { id: 'chat', label: 'AI Chat', icon: MessageSquare },
    { id: 'trending', label: 'Trending', icon: TrendingUp },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-black/90 border-t border-white/5 backdrop-blur-md pb-safe-bottom">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-between relative">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          if (item.isCenter) {
            return (
              <button
                key={item.id}
                onClick={() => setTab(item.id)}
                className="relative -top-5 flex flex-col items-center group focus:outline-none"
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#00FF41] to-[#008F24] flex items-center justify-center shadow-[0_0_15px_rgba(0,255,65,0.4)] active:scale-95 transition-transform duration-200 border-4 border-[#050505]">
                  <Icon className="w-6 h-6 text-black stroke-[2.5]" />
                </div>
                <span className="text-[10px] mt-1 font-bold text-[#00FF41] tracking-wide">
                  AI SCAN
                </span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className="flex flex-col items-center justify-center flex-1 h-full py-1 text-xs transition-colors duration-200 focus:outline-none relative"
            >
              <div className="relative py-1 px-3">
                {isActive && (
                  <motion.div
                    layoutId="activeTabGlow"
                    className="absolute inset-0 bg-white/5 rounded-full -z-10"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <Icon
                  className={`w-5 h-5 mx-auto transition-transform duration-200 ${
                    isActive ? 'text-[#00FF41] scale-110' : 'text-neutral-500 hover:text-neutral-300'
                  }`}
                  strokeWidth={isActive ? 2.5 : 2}
                />
              </div>
              <span
                className={`text-[9px] mt-0.5 tracking-wider font-extrabold uppercase ${
                  isActive ? 'text-[#00FF41]' : 'text-neutral-500'
                }`}
              >
                {item.label === 'Live Predictions' ? 'Live' : item.label === 'AI Chat' ? 'Chat' : item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
