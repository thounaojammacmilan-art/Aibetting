import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, AlertTriangle, ShieldCheck, Coins, MessageSquare, History } from 'lucide-react';
import { ChatMessage, BettingSlipAnalysis } from '../types';

interface AIChatBotProps {
  currentAnalysis: BettingSlipAnalysis | null;
}

export default function AIChatBot({ currentAnalysis }: AIChatBotProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "### 🤖 MILAN AI Sports Analyst\nGreetings! I am the MILAN AI core sports advisor. I analyze live scoreboard trends, squad fatigue levels, and tactical systems of play.\n\n" + 
            (currentAnalysis 
              ? `I see you have an active analysis for **${currentAnalysis.teams.home} vs ${currentAnalysis.teams.away}** loaded in memory! Ask me any specific tactical, spread, or hazard questions about this slip.` 
              : "Ask me questions like **'Which bet is safest?'** or **'Suggest a safe parlay strategy'** to begin!"),
      timestamp: new Date().toISOString(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    { label: '🛡️ Which bet is safest?', text: 'Which bet is safest for my loaded slip?' },
    { label: '⚠️ Calculate parlay risk', text: 'Analyze multi-match parlay risks and list weak legs.' },
    { label: '📊 Best high-confidence pick', text: 'Which current league fixture offers the absolute best high-probability ROI?' },
  ];

  // Auto-scroll to lowest chat bubble on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: 'msg_' + Date.now(),
      role: 'user',
      text: textToSend,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      // Setup payload including context
      const response = await fetch('/api/chat-assistant', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          context: currentAnalysis,
          history: messages.map((m) => ({
            role: m.role,
            text: m.text,
          })),
        }),
      });

      const data = await response.json();
      const modelMsg: ChatMessage = {
        id: 'msg_' + Date.now(),
        role: 'model',
        text: data.text || 'My neural matrix is currently synchronizing with live sport streams. Let us look at Double Chance variables.',
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, modelMsg]);
    } catch (err) {
      console.error('Chat interface API error:', err);
      // Graceful local simulated response fallback
      setTimeout(() => {
        const fallbackMsg: ChatMessage = {
          id: 'msg_' + Date.now(),
          role: 'model',
          text: `### 🛡️ AI Hedge Report\nAnalyzing live indices under offline conditions:\n\n- Suggesting **Double Chance (1X)** to protect margins.\n- Avoid straight bets on long-odds draws given historical momentum parameters.`,
          timestamp: new Date().toISOString(),
        };
        setMessages((prev) => [...prev, fallbackMsg]);
      }, 1000);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick helper to render markdown sections nicely
  const parseMarkdownText = (raw: string) => {
    // Simple parser for headings and bullet points
    return raw.split('\n').map((line, i) => {
      if (line.startsWith('### ')) {
        return <h4 key={i} className="text-xs font-black text-[#00E676] uppercase tracking-wider mt-3 mb-1">{line.replace('### ', '')}</h4>;
      }
      if (line.startsWith('## ')) {
        return <h3 key={i} className="text-xs font-black text-[#00E676] uppercase tracking-wider mt-3 mb-2">{line.replace('## ', '')}</h3>;
      }
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return <li key={i} className="ml-3 list-disc text-[11px] text-neutral-300 leading-relaxed">{line.slice(2)}</li>;
      }
      if (line.match(/^\d+\./)) {
        return <li key={i} className="ml-3 list-decimal text-[11px] text-neutral-300 leading-relaxed">{line.replace(/^\d+\.\s*/, '')}</li>;
      }
      return <p key={i} className="text-xs text-neutral-200 leading-relaxed font-sans mt-1">{line}</p>;
    });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] max-w-md mx-auto">
      {/* Active Slip Context Bar */}
      {currentAnalysis && (
        <div className="bg-neutral-900 border border-[#00E676]/20 py-2 px-3 rounded-xl flex items-center justify-between mb-3 shrink-0">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#00E676] stroke-[2]" />
            <span className="text-[10px] text-neutral-300 font-bold font-mono">
              Slip In Context: {currentAnalysis.teams.home} vs {currentAnalysis.teams.away}
            </span>
          </div>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 font-mono font-bold uppercase">
            ACTIVE
          </span>
        </div>
      )}

      {/* Messages Window Scroll-port */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1 pb-4 min-h-0">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col max-w-[85%] ${
              msg.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
            }`}
          >
            <div
              className={`rounded-2xl px-3.5 py-2.5 shadow-md ${
                msg.role === 'user'
                  ? 'bg-gradient-to-tr from-[#00E676] to-emerald-500 text-neutral-950 font-bold text-xs'
                  : 'bg-neutral-900 border border-neutral-850 text-neutral-200'
              }`}
            >
              <div className="space-y-1">
                {msg.role === 'user' ? <p>{msg.text}</p> : parseMarkdownText(msg.text)}
              </div>
            </div>
            <span className="text-[9px] text-neutral-500 font-mono mt-1 px-1">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 bg-neutral-900/60 border border-neutral-850 px-3.5 py-2.5 rounded-2xl max-w-[140px]">
            <Sparkles className="w-3.5 h-3.5 text-[#00E676] animate-spin shrink-0" />
            <span className="text-[10px] text-neutral-400 font-mono animate-pulse">Analyzing...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestion buttons */}
      <div className="space-y-2 mt-2 shrink-0">
        <div className="flex gap-1.5 overflow-x-auto pb-1.5 scrollbar-thin scrollbar-thumb-neutral-800">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(qp.text)}
              className="bg-neutral-905 border border-neutral-800 px-3 py-1.5 rounded-full text-[10px] font-bold text-neutral-300 hover:text-[#00E676] hover:border-[#00E676]/30 shrink-0 select-none active:scale-95 transition-all text-ellipsis"
            >
              {qp.label}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="flex gap-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage(inputValue)}
            placeholder="Ask sportsbook AI counselor..."
            className="flex-1 bg-neutral-900 border border-neutral-800/80 rounded-xl px-3.5 py-2.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-[#00E676]/50 transition-colors"
          />
          <button
            onClick={() => handleSendMessage(inputValue)}
            className="w-10 h-10 rounded-xl bg-[#00E676] hover:bg-emerald-400 text-neutral-950 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-900/10 transition-colors"
          >
            <Send className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>
    </div>
  );
}
