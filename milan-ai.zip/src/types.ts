export interface AlternativePick {
  betType: string;
  odds: number;
  probabilityPercent: number;
  reasoning: string;
}

export interface PredictionDetail {
  winnerSelection: string;
  probabilityPercent: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  label: string; // e.g., "AI safest play", "High Volatility Value"
  confidenceMeter: number;
  predictedScore: string;
  reasoning: string[];
  alternativeSaferPick: AlternativePick;
}

export interface TeamAnalytics {
  homeForm: ('W' | 'D' | 'L')[];
  awayForm: ('W' | 'D' | 'L')[];
  homeMomentum: number; // 0-100
  awayMomentum: number; // 0-100
  headToHead: string;
  matchVolatility: 'LOW' | 'MEDIUM' | 'HIGH';
  tacticalInsight: string;
  dominionLevel: number; // 0-100
}

export interface ParlayMatch {
  matchName: string;
  detectedOdds: number;
  prediction: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  probabilityPercent: number;
  suggestedAlternative: string;
  alternativeOdds: number;
}

export interface ParlayAnalysis {
  overallSlipRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  weakestLink: string;
  suggestedReplacement: string;
  originalCombinedOdds: number;
  optimizedCombinedOdds: number;
  summary: string;
  individualMatches?: ParlayMatch[];
}

export interface BettingSlipAnalysis {
  id: string;
  timestamp: string;
  detectedPlatform: string;
  isSlipValidOrDetected: boolean;
  sport: string;
  tournament: string;
  matchTime: string;
  teams: {
    home: string;
    away: string;
  };
  betType: string;
  oddsOnSlip: number;
  currentScore?: string;
  prediction: PredictionDetail;
  analytics: TeamAnalytics;
  parlayAnalyzer?: ParlayAnalysis;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export interface LiveMatch {
  id: string;
  homeTeam: string;
  awayTeam: string;
  sport: string;
  tournament: string;
  minute: number;
  score: string;
  oddsHome: number;
  oddsAway: number;
  oddsDraw: number;
  oddsDirection: 'up' | 'down' | 'stable';
  aiConfidence: number;
  aiPick: string;
  volatility: 'LOW' | 'MEDIUM' | 'HIGH';
  isLive: boolean;
}

export interface TrendingPick {
  id: string;
  homeTeam: string;
  awayTeam: string;
  tournament: string;
  betType: string;
  odds: number;
  aiConfidence: number;
  analyzedCount: number;
  formHome: ('W' | 'D' | 'L')[];
  formAway: ('W' | 'D' | 'L')[];
}
