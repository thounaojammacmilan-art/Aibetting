import { BettingSlipAnalysis } from '../types';

export const PRESET_SLIPS: (BettingSlipAnalysis & { label: string; platformLogo: string; description: string; imageUrl?: string })[] = [
  {
    id: 'preset_1xbet_elclasico',
    label: '1xBet - El Clásico Single',
    platformLogo: '1xBet',
    description: 'La Liga: Real Madrid vs Barcelona (Match Result Win Bet)',
    timestamp: new Date().toISOString(),
    detectedPlatform: '1xBet',
    isSlipValidOrDetected: true,
    sport: 'Soccer',
    tournament: 'Spain - La Liga',
    matchTime: '2026-05-30 Matchday',
    teams: {
      home: 'Real Madrid',
      away: 'FC Barcelona'
    },
    betType: 'Real Madrid to win (1)',
    oddsOnSlip: 2.15,
    prediction: {
      winnerSelection: 'Real Madrid',
      probabilityPercent: 54,
      riskLevel: 'MEDIUM',
      label: 'AI Balanced Value Play',
      confidenceMeter: 72,
      predictedScore: '2-1',
      reasoning: [
        'Real Madrid remains undefeated at the Santiago Bernabéu in their last 14 matches.',
        'FC Barcelona is missing key defensive anchor Ronald Araújo due to suspensions.',
        'Vinícius Júnior is averaging 1.2 big chances created per match in this matchup over the last 3 seasons.'
      ],
      alternativeSaferPick: {
        betType: 'Real Madrid Double Chance (1X)',
        odds: 1.35,
        probabilityPercent: 82,
        reasoning: 'Hedges against a late equalizing draw. Offers stellar protection under low hazard.'
      }
    },
    analytics: {
      homeForm: ['W', 'D', 'W', 'W', 'W'],
      awayForm: ['W', 'L', 'W', 'D', 'W'],
      homeMomentum: 88,
      awayMomentum: 74,
      headToHead: 'Last 5 games: 3 Real Madrid wins, 1 Barcelona win, 1 Draw',
      matchVolatility: 'MEDIUM',
      tacticalInsight: 'Real Madrid is expected to set up in an aggressive 4-3-1-2 diamond, exploiting transitions through Vinícius and Mbappé. Barcelona will try to dominate possession, but their high-defensive line is vulnerable to extreme speed.',
      dominionLevel: 68
    }
  },
  {
    id: 'preset_stake_parlay',
    label: 'Stake - English Premier League 3-Fold Parlay',
    platformLogo: 'Stake',
    description: 'Combo Slip: Man City, Arsenal & Liverpool Parlay',
    timestamp: new Date().toISOString(),
    detectedPlatform: 'Stake',
    isSlipValidOrDetected: true,
    sport: 'Soccer',
    tournament: 'England - Premier League',
    matchTime: '2026-05-28 Premier League Slate',
    teams: {
      home: 'Multi-Match Combo',
      away: 'Slip'
    },
    betType: '3-Match Parlay',
    oddsOnSlip: 3.42,
    prediction: {
      winnerSelection: 'Arsenal & Liverpool to Win, Man City to Draw/Win',
      probabilityPercent: 44,
      riskLevel: 'HIGH',
      label: 'AI Aggressive Multi-Bet',
      confidenceMeter: 48,
      predictedScore: 'Parlay (3 Legs)',
      reasoning: [
        'Liverpool is on a 6-match winning streak against bottom-half opponents.',
        'Arsenal faces Bournemouth at the Emirates, maintaining a high 81% win rate at home.',
        'Man City faces Aston Villa away, which is historically a high-scoring and volatile matchup. Villa is in highly aggressive home form.'
      ],
      alternativeSaferPick: {
        betType: '2-Leg Parlay (Arsenal Win + Liverpool Win) excluding Man City leg',
        odds: 2.10,
        probabilityPercent: 78,
        reasoning: 'Excluding City at Villa Park reduces cumulative volatility by 35% while keeping decent value.'
      }
    },
    analytics: {
      homeForm: ['W', 'W', 'W', 'D', 'W'],
      awayForm: ['W', 'W', 'D', 'L', 'W'],
      homeMomentum: 92,
      awayMomentum: 85,
      headToHead: 'Varies by match pairings',
      matchVolatility: 'HIGH',
      tacticalInsight: 'Combining multiple favorites often dilutes real betting value. Our risk engine flags Manchester City vs Aston Villa as an extreme tactical hazard, as Villa’s low-block counter could easily trigger an upset.',
      dominionLevel: 45
    },
    parlayAnalyzer: {
      overallSlipRisk: 'HIGH',
      weakestLink: 'Manchester City vs Aston Villa (Man City to Win)',
      suggestedReplacement: 'Man City Double Chance (X2) or Draw No Bet',
      originalCombinedOdds: 3.42,
      optimizedCombinedOdds: 2.65,
      summary: 'Your parlay is held back by the City leg. Removing it or substituting with a Double Chance improves probability from 44% to 68%.',
      individualMatches: [
        {
          matchName: 'Man City vs Aston Villa',
          detectedOdds: 1.63,
          prediction: 'Man City to Win',
          riskLevel: 'HIGH',
          probabilityPercent: 55,
          suggestedAlternative: 'Draw or Man City (X2)',
          alternativeOdds: 1.18
        },
        {
          matchName: 'Arsenal vs Bournemouth',
          detectedOdds: 1.30,
          prediction: 'Arsenal to Win',
          riskLevel: 'LOW',
          probabilityPercent: 80,
          suggestedAlternative: 'Arsenal to Win',
          alternativeOdds: 1.30
        },
        {
          matchName: 'Liverpool vs Everton',
          detectedOdds: 1.45,
          prediction: 'Liverpool to Win',
          riskLevel: 'LOW',
          probabilityPercent: 75,
          suggestedAlternative: 'Liverpool to Win',
          alternativeOdds: 1.45
        }
      ]
    }
  },
  {
    id: 'preset_bet365_nba',
    label: 'Bet365 - NBA Finals Game 1',
    platformLogo: 'Bet365',
    description: 'NBA Basketball: Boston Celtics vs LA Lakers Handicap Bet',
    timestamp: new Date().toISOString(),
    detectedPlatform: 'Bet365',
    isSlipValidOrDetected: true,
    sport: 'Basketball',
    tournament: 'NBA - Playoffs',
    matchTime: '2026-06-02 Finals',
    teams: {
      home: 'Boston Celtics',
      away: 'LA Lakers'
    },
    betType: 'LA Lakers +5.5 Point Spread',
    oddsOnSlip: 1.90,
    prediction: {
      winnerSelection: 'LA Lakers (+5.5)',
      probabilityPercent: 68,
      riskLevel: 'LOW',
      label: 'AI Solid Handicap Asset',
      confidenceMeter: 84,
      predictedScore: '112-109 (Celtics Win, Lakers Cover)',
      reasoning: [
        'Lakers cover the spread in 74% of playoff games following a rest period of 3+ days.',
        'Boston Celtics struggle with perimeter defense when Kristaps Porziņģis switches outside.',
        'Anthony Davis is on an elite offensive run, scoring 28+ points in 4 consecutive matchups.'
      ],
      alternativeSaferPick: {
        betType: 'LA Lakers +8.5 Alternate Spread',
        odds: 1.62,
        probabilityPercent: 85,
        reasoning: 'Extremely high likelihood of covering even under a late-game free throw barrage.'
      }
    },
    analytics: {
      homeForm: ['W', 'W', 'L', 'W', 'W'],
      awayForm: ['W', 'W', 'W', 'W', 'L'],
      homeMomentum: 80,
      awayMomentum: 89,
      headToHead: 'Season series tied 1-1, both games went to overtime.',
      matchVolatility: 'LOW',
      tacticalInsight: 'Lakers match up excellently with Celtic’s paint-orientated offense. Anthony Davis dominates key matchups, driving high value to the spread point lines.',
      dominionLevel: 82
    }
  }
];

export const MOCK_TRENDING: any[] = [
  {
    id: 'trend_1',
    homeTeam: 'Arsenal',
    awayTeam: 'Chelsea',
    tournament: 'England - Premier League',
    betType: 'Arsenal to win',
    odds: 1.65,
    aiConfidence: 89,
    analyzedCount: 1420,
    formHome: ['W', 'W', 'D', 'W', 'W'],
    formAway: ['W', 'L', 'D', 'W', 'L']
  },
  {
    id: 'trend_2',
    homeTeam: 'Paris SG',
    awayTeam: 'Marseille',
    tournament: 'France - Ligue 1',
    betType: 'Over 2.5 Goals',
    odds: 1.55,
    aiConfidence: 82,
    analyzedCount: 980,
    formHome: ['W', 'W', 'W', 'D', 'W'],
    formAway: ['D', 'W', 'L', 'W', 'D']
  },
  {
    id: 'trend_3',
    homeTeam: 'Milwaukee Bucks',
    awayTeam: 'Miami Heat',
    tournament: 'NBA Basketball',
    betType: 'Bucks -3.5 Handicap',
    odds: 1.82,
    aiConfidence: 78,
    analyzedCount: 840,
    formHome: ['L', 'W', 'W', 'L', 'W'],
    formAway: ['W', 'D', 'W', 'W', 'L']
  }
];

export const MOCK_LIVE: any[] = [
  {
    id: 'live_1',
    homeTeam: 'Borussia Dortmund',
    awayTeam: 'Bayern Munich',
    sport: 'Soccer',
    tournament: 'Germany - Bundesliga',
    minute: 74,
    score: '2-2',
    oddsHome: 3.10,
    oddsAway: 2.25,
    oddsDraw: 2.80,
    oddsDirection: 'up',
    aiConfidence: 75,
    aiPick: 'Bayern Munich Draw No Bet',
    volatility: 'HIGH',
    isLive: true
  },
  {
    id: 'live_2',
    homeTeam: 'Golden State Warriors',
    awayTeam: 'Phoenix Suns',
    sport: 'Basketball',
    tournament: 'NBA Basketball',
    minute: 3, // 3rd Quarter
    score: '84-81',
    oddsHome: 1.70,
    oddsAway: 2.15,
    oddsDraw: 0,
    oddsDirection: 'down',
    aiConfidence: 84,
    aiPick: 'Warriors to Win',
    volatility: 'LOW',
    isLive: true
  }
];
