import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import BottomNavBar from './components/BottomNavBar';
import UploadSection from './components/UploadSection';
import AnalysisDashboard from './components/AnalysisDashboard';
import MatchDetailView from './components/MatchDetailView';
import LivePredictions from './components/LivePredictions';
import AIChatBot from './components/AIChatBot';
import TrendingPicks from './components/TrendingPicks';
import { BettingSlipAnalysis } from './types';
import { 
  Trophy, 
  Flame, 
  History, 
  Sparkles, 
  Trash2, 
  ArrowRight, 
  Camera, 
  ShieldCheck, 
  BadgePercent,
  Coins
} from 'lucide-react';
import { PRESET_SLIPS } from './data/presets';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentTab, setTab] = useState('home');
  const [savedAnalyses, setSavedAnalyses] = useState<BettingSlipAnalysis[]>([]);
  const [activeAnalysis, setActiveAnalysis] = useState<BettingSlipAnalysis | null>(null);
  const [isDetailedPlaybookOpen, setIsDetailedPlaybookOpen] = useState(false);

  // Load saved analyses on mount
  useEffect(() => {
    const local = localStorage.getItem('oddsshield_scans');
    if (local) {
      try {
        setSavedAnalyses(JSON.parse(local));
      } catch (e) {
        console.error('Error loading saved scans:', e);
      }
    }
  }, []);

  // Save changes to localstorage helper
  const saveAnalysisRecord = (newRecord: BettingSlipAnalysis) => {
    const updated = [newRecord, ...savedAnalyses.filter(item => item.id !== newRecord.id)];
    setSavedAnalyses(updated);
    localStorage.setItem('oddsshield_scans', JSON.stringify(updated));
  };

  const clearAllSavedAnalyses = () => {
    setSavedAnalyses([]);
    localStorage.removeItem('oddsshield_scans');
  };

  const handleAnalysisStarted = () => {
    // Put UI into scans tab
    setTab('upload');
    setActiveAnalysis(null);
    setIsDetailedPlaybookOpen(false);
  };

  const handleAnalysisCompleted = (result: BettingSlipAnalysis) => {
    setActiveAnalysis(result);
    setIsDetailedPlaybookOpen(false);
    saveAnalysisRecord(result);
  };

  const selectSavedScan = (scan: BettingSlipAnalysis) => {
    setActiveAnalysis(scan);
    setIsDetailedPlaybookOpen(false);
    setTab('upload');
  };

  const handleOptimizeParlay = (optimizedResult: BettingSlipAnalysis) => {
    setActiveAnalysis(optimizedResult);
    saveAnalysisRecord(optimizedResult);
  };

  const handleSetTab = (tab: string) => {
    if (tab === 'upload') {
      setActiveAnalysis(null);
      setIsDetailedPlaybookOpen(false);
    }
    setTab(tab);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#F5F5F7] flex flex-col font-sans select-none antialiased max-w-md mx-auto relative shadow-[0_0_80px_rgba(0,0,0,0.9)] border-x border-white/10">
      {/* Premium Sportsbook Header */}
      <Header />

      {/* Main View Port Container */}
      <main className="flex-1 overflow-y-auto px-4 pt-4 pb-24">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab + (activeAnalysis ? activeAnalysis.id : '') + (isDetailedPlaybookOpen ? 'detailed' : '')}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.18 }}
            className="h-full"
          >
            {/* HOME VIEW */}
            {currentTab === 'home' && (
              <div className="space-y-6">
                {/* Greeting banner with background blur effect */}
                <div className="relative bg-white/5 border border-white/10 rounded-2xl p-4 flex items-center justify-between overflow-hidden">
                  <div className="absolute top-0 left-0 w-24 h-24 bg-[#00FF41]/10 rounded-full blur-2xl -z-10" />
                  <div className="space-y-1 relative z-10">
                    <p className="text-[10px] text-[#00FF41] font-mono uppercase font-black tracking-widest flex items-center gap-1.5 animate-pulse">
                      <Sparkles className="w-3.5 h-3.5" /> Core Neural Online
                    </p>
                    <h2 className="text-base font-black text-white tracking-tight">VIP Betting Adviser</h2>
                    <p className="text-[10.5px] text-gray-400">Upload live tickets to scan safe hedging odds.</p>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center text-[#00FF41] shadow-inner relative z-10">
                    <Trophy className="w-5 h-5 animate-bounce" style={{ animationDuration: '3s' }} />
                  </div>
                </div>

                {/* Android-first Quick Scan Launcher Call to Action */}
                <button
                  onClick={() => handleSetTab('upload')}
                  className="w-full bg-[#00FF41] hover:scale-[0.98] text-black font-extrabold text-xs py-3.5 px-4 rounded-xl shadow-[0_8px_30px_rgba(0,255,65,0.25)] transition-all duration-250 flex items-center justify-between group active:scale-98"
                >
                  <div className="flex items-center gap-2">
                    <Camera className="w-4 h-4 stroke-[2.5]" />
                    <span>LAUNCH SPORTSBOOK SCREEN SCANNER</span>
                  </div>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform stroke-[2.5]" />
                </button>

                {/* Quick stats columns */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 space-y-1 flex flex-col justify-between">
                    <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Scanned Records</span>
                    <div className="flex items-baseline gap-2 pt-1.5">
                      <span className="text-xl font-black text-[#00FF41] font-mono">{savedAnalyses.length}</span>
                      <span className="text-[10px] text-gray-500 font-mono">tickets</span>
                    </div>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 space-y-1 flex flex-col justify-between">
                    <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">VIP Odds Hedges</span>
                    <div className="flex items-baseline gap-2 pt-1.5">
                      <span className="text-xl font-black text-[#D4AF37] font-mono">
                        {savedAnalyses.filter(item => item.prediction?.alternativeSaferPick).length}
                      </span>
                      <span className="text-[10px] text-gray-500 font-mono">hedges</span>
                    </div>
                  </div>
                </div>

                {/* Saved Recent Local Analyses list */}
                {savedAnalyses.length > 0 ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
                      <div className="flex items-center gap-1.5 text-gray-200">
                        <History className="w-4 h-4 text-[#00FF41]" />
                        <h3 className="text-xs font-black uppercase tracking-wider">Recent Local Scans</h3>
                      </div>
                      <button
                        onClick={clearAllSavedAnalyses}
                        className="text-[10px] font-bold text-red-400 flex items-center gap-1 hover:text-red-300 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                        Clear All
                      </button>
                    </div>

                    <div className="space-y-2">
                      {savedAnalyses.map((scan) => (
                        <div
                          key={scan.id}
                          onClick={() => selectSavedScan(scan)}
                          className="group bg-white/5 border border-white/10 hover:border-white/20 rounded-xl p-3 flex items-center justify-between cursor-pointer transition-all active:scale-[0.99]"
                        >
                          <div className="space-y-1">
                            <p className="text-[9px] text-[#00FF41] font-mono font-bold uppercase tracking-wider">
                              {scan.detectedPlatform} / {scan.sport}
                            </p>
                            <h4 className="text-xs font-bold text-white">
                              {scan.teams.home} vs {scan.teams.away}
                            </h4>
                            <p className="text-[10px] text-gray-400">
                              Target bet: {scan.betType} (Odds {scan.oddsOnSlip})
                            </p>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="inline-block text-[10px] font-bold py-0.5 px-2 rounded-full bg-[#00FF41]/10 border border-[#00FF41]/30 text-[#00FF41] font-mono">
                              {scan.prediction.probabilityPercent}%
                            </span>
                            <span className="block text-[8px] text-gray-500 font-mono uppercase tracking-wider mt-1">Win Probability</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="bg-white/5 border border-white/10 border-dashed rounded-xl p-6 text-center space-y-1.5">
                    <p className="text-xs font-bold text-gray-300">No scanned tickets loaded yet</p>
                    <p className="text-[10px] text-gray-400 max-w-xs mx-auto">
                      Use the active center scanner or tap of our interactive preset templates under the scan screen to see AI risk predictions instantly.
                    </p>
                  </div>
                )}

                {/* Popular sample match guidelines slider */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center gap-1">
                    <Flame className="w-4 h-4 text-[#D4AF37] animate-pulse" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-gray-100">Featured High Chance Opportunities</h3>
                  </div>
                  <div className="space-y-2">
                    {PRESET_SLIPS.slice(0, 2).map((slip) => (
                      <div 
                        key={slip.id}
                        onClick={() => selectSavedScan(slip)}
                        className="p-3 bg-black/40 rounded-xl border border-white/5 hover:border-white/10 transition-all cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <p className="text-[10px] font-bold text-gray-400 font-mono uppercase">{slip.tournament}</p>
                          <h4 className="text-xs font-bold text-white mt-0.5">{slip.label}</h4>
                        </div>
                        <span className="text-[10px] font-black text-[#D4AF37] font-mono bg-[#D4AF37]/10 px-2 py-0.5 rounded border border-[#D4AF37]/30">
                          ODDS {slip.oddsOnSlip}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* SCAN TABS PAGE VIEW */}
            {currentTab === 'upload' && (
              <div className="h-full">
                {!activeAnalysis ? (
                  // If no active analyzed ticket context, let them upload
                  <UploadSection
                    onAnalysisStarted={handleAnalysisStarted}
                    onAnalysisCompleted={handleAnalysisCompleted}
                  />
                ) : (
                  // Render parsed analysis, with full detailed playbook toggles
                  <div>
                    {!isDetailedPlaybookOpen ? (
                      <AnalysisDashboard
                        analysis={activeAnalysis}
                        onViewMatchDetails={() => setIsDetailedPlaybookOpen(true)}
                        onOptimizeParlay={handleOptimizeParlay}
                        onNewScan={() => handleSetTab('upload')}
                      />
                    ) : (
                      <MatchDetailView
                        analysis={activeAnalysis}
                        onBack={() => setIsDetailedPlaybookOpen(false)}
                      />
                    )}
                  </div>
                )}
              </div>
            )}

            {/* LIVE FEED TAB VIEW */}
            {currentTab === 'live' && <LivePredictions />}

            {/* CHAT TAB VIEW */}
            {currentTab === 'chat' && <AIChatBot currentAnalysis={activeAnalysis} />}

            {/* TRENDING TAB VIEW */}
            {currentTab === 'trending' && (
              <TrendingPicks
                onSelectPreset={handleAnalysisCompleted}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Floating Bottom Navigation Menu */}
      <BottomNavBar currentTab={currentTab} setTab={handleSetTab} />
    </div>
  );
}
